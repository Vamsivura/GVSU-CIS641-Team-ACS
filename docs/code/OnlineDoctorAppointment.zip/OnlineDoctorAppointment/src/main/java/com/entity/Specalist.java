package com.entity;

public class Specalist {
	private int id;
	private String specialisrName;
	
	public Specalist() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Specalist(int id, String specialisrName) {
		super();
		this.id = id;
		this.specialisrName = specialisrName;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSpecialistName() {
		return specialisrName;
	}
	public void setSpecialistName(String specialisrName) {
		this.specialisrName = specialisrName;
	}
	

}
